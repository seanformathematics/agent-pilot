
import math, random
import numpy as np

def make_nb(L):
    nb = []
    for i in range(L):
        for j in range(L):
            nb.append((((i+1) % L)*L + j, ((i-1) % L)*L + j, i*L + (j+1) % L, i*L + (j-1) % L))
    return nb

def run_flips(spins, mark, stamp, M, nfl, padd, rnd, nb, N):
    """Perform nfl Wolff cluster flips; after each flip record m^2 and m^4 (m=M/N).
    Returns (M, stamp, sum m^2, sum m^4)."""
    S2 = 0.0; S4 = 0.0
    Nf = float(N)
    for _ in range(nfl):
        seed = int(rnd()*N)
        s0 = spins[seed]
        stamp += 1
        mark[seed] = stamp
        cl = [seed]
        for c in cl:
            for q in nb[c]:
                if mark[q] != stamp and spins[q] == s0 and rnd() < padd:
                    mark[q] = stamp
                    cl.append(q)
        for c in cl:
            spins[c] = -s0
        M -= 2*s0*len(cl)
        m2 = (M/Nf)**2
        S2 += m2
        S4 += m2*m2
    return M, stamp, S2, S4

def jk_U(S2b, S4b, cnt):
    """Binder U = 1 - <m^4>/(3<m^2>^2) from block sums, with delete-one-block jackknife error."""
    S2 = S2b.sum(); S4 = S4b.sum(); n = cnt.sum()
    U = 1 - n*S4/(3*S2**2)
    Um = 1 - (n-cnt)*(S4-S4b)/(3*(S2-S2b)**2)
    B = len(S2b)
    err = math.sqrt((B-1)/B*np.sum((Um-Um.mean())**2))
    return float(U), float(err)


import numpy as np, math, time, json, os

def wolff_step(s, rng, p, N, R, ar):
    # bonds: open with prob p if the two spins are aligned (periodic boundaries)
    bR = (s == np.roll(s, -1, axis=1)) & (rng.random((N, N, R), dtype=np.float32) < p)
    bD = (s == np.roll(s, -1, axis=0)) & (rng.random((N, N, R), dtype=np.float32) < p)
    bL = np.roll(bR, 1, axis=1)
    bU = np.roll(bD, 1, axis=0)
    i0 = rng.integers(0, N, R)
    j0 = rng.integers(0, N, R)
    C = np.zeros((N, N, R), dtype=bool)
    C[i0, j0, ar] = True            # Wolff seed site per replica
    iters = 0
    while True:                     # flood fill = Wolff cluster through open bonds
        iters += 1
        new = (C | np.roll(C & bR, 1, axis=1) | np.roll(C & bL, -1, axis=1)
                 | np.roll(C & bD, 1, axis=0) | np.roll(C & bU, -1, axis=0))
        if np.array_equal(new, C):
            break
        C = new
    s = np.where(C, -s, s).astype(np.int8)
    return s, iters

def run_chain(N, R, T, nburn, nmeas, seed):
    rng = np.random.default_rng(seed)
    p = 1.0 - math.exp(-2.0 / T)
    ar = np.arange(R)
    s = np.where(rng.random((N, N, R)) < 0.5, 1, -1).astype(np.int8)   # random (infinite-T) start
    hist = []
    for t in range(nburn):
        s, it = wolff_step(s, rng, p, N, R, ar)
        m = s.sum(axis=(0, 1), dtype=np.int32) / (N * N)
        hist.append(float((m * m).mean()))
    m2 = np.empty((nmeas, R)); m4 = np.empty((nmeas, R)); iters_tot = 0
    t0 = time.time()
    for t in range(nmeas):
        s, it = wolff_step(s, rng, p, N, R, ar)
        iters_tot += it
        m = s.sum(axis=(0, 1), dtype=np.int32) / (N * N)
        m2[t] = m * m; m4[t] = m ** 4
        hist.append(float((m * m).mean()))
    el = time.time() - t0
    return m2.T.copy(), m4.T.copy(), np.array(hist), el, iters_tot / nmeas

def jack_U_rep(S2, S4, n):
    # replica-level jackknife: S2,S4 are per-replica sums over n samples
    R = S2.shape[0]
    tot2 = S2.sum(); tot4 = S4.sum()
    B = tot2 / (R * n); A = tot4 / (R * n)
    U = 1 - A / (3 * B * B)
    B_i = (tot2 - S2) / ((R - 1) * n); A_i = (tot4 - S4) / ((R - 1) * n)
    U_i = 1 - A_i / (3 * B_i ** 2)
    err = math.sqrt((R - 1) / R * np.sum((U_i - U_i.mean()) ** 2))
    return U, err

def block_jk(m2, m4, b):
    # block jackknife over (replica, time-block) blocks of length b
    R, S = m2.shape
    nb = S // b
    x2 = m2[:, :nb * b].reshape(R, nb, b).sum(axis=2).ravel()
    x4 = m4[:, :nb * b].reshape(R, nb, b).sum(axis=2).ravel()
    n = R * nb * b
    T2 = x2.sum(); T4 = x4.sum()
    U = 1 - (T4 / n) / (3 * (T2 / n) ** 2)
    nn = n - b
    B_i = (T2 - x2) / nn; A_i = (T4 - x4) / nn
    U_i = 1 - A_i / (3 * B_i ** 2)
    K = len(x2)
    err = math.sqrt((K - 1) / K * np.sum((U_i - U_i.mean()) ** 2))
    return U, err

def tau_int(x):
    R, S = x.shape
    y = x - x.mean()
    nfft = 1 << (2 * S - 1).bit_length()
    F = np.fft.rfft(y, n=nfft, axis=1)
    acf = np.fft.irfft(F * np.conj(F), n=nfft, axis=1)[:, :S].mean(axis=0)
    acf = acf / acf[0]
    tau = 0.5
    for W in range(1, S):
        tau = 0.5 + acf[1:W + 1].sum()
        if W >= 5 * tau:
            break
    return float(tau)


import numpy as np

def wolff_run(N, T, R, nsteps, seed, s0=None):
    """Vectorized Wolff: R independent replicas advanced in lockstep.
    Returns magnetization sums M_t = sum_i s_i (int16), shape (nsteps, R), and final spins."""
    rng = np.random.default_rng(seed)
    p = 1.0 - np.exp(-2.0 / T)
    if s0 is None:
        s = rng.integers(0, 2, size=(R, N, N), dtype=np.int8) * 2 - 1
    else:
        s = s0.copy()
    s = s.astype(np.int8)
    ar = np.arange(R)
    Mt = np.empty((nsteps, R), dtype=np.int16)
    for t in range(nsteps):
        sr = np.roll(s, -1, axis=2)
        sd = np.roll(s, -1, axis=1)
        open_r = (s == sr) & (rng.random((R, N, N)) < p)
        open_d = (s == sd) & (rng.random((R, N, N)) < p)
        seeds = rng.integers(0, N * N, size=R)
        C = np.zeros((R, N * N), dtype=bool)
        C[ar, seeds] = True
        C = C.reshape(R, N, N)
        while True:
            newC = (C | np.roll(C & open_r, 1, axis=2) | (open_r & np.roll(C, -1, axis=2))
                    | np.roll(C & open_d, 1, axis=1) | (open_d & np.roll(C, -1, axis=1)))
            if np.array_equal(newC, C):
                break
            C = newC
        s = np.where(C, -s, s).astype(np.int8)
        Mt[t] = s.reshape(R, -1).sum(axis=1, dtype=np.int32)
    return Mt, s

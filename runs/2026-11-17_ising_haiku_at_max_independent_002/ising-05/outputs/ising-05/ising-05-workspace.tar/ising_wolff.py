
import numpy as np
from numba import njit

def make_nbr(L):
    N = L*L
    nbr = np.empty((N, 4), dtype=np.int64)
    for x in range(L):
        for y in range(L):
            i = x*L + y
            nbr[i, 0] = ((x+1) % L)*L + y
            nbr[i, 1] = ((x-1) % L)*L + y
            nbr[i, 2] = x*L + (y+1) % L
            nbr[i, 3] = x*L + (y-1) % L
    return nbr

@njit(cache=True)
def wolff_blocks(nbr, N, beta, seed, n_therm, n_blocks, block_len, init_mode):
    np.random.seed(seed)
    spins = np.ones(N, dtype=np.int64)
    if init_mode == 0:
        for i in range(N):
            if np.random.random() < 0.5:
                spins[i] = -1
    M = 0
    for i in range(N):
        M += spins[i]
    padd = 1.0 - np.exp(-2.0*beta)
    stamp = np.zeros(N, dtype=np.int64)
    clust = np.empty(N, dtype=np.int64)
    S2 = np.zeros(n_blocks, dtype=np.int64)
    S4 = np.zeros(n_blocks, dtype=np.int64)
    cur = 0
    total = n_therm + n_blocks*block_len
    s2 = 0
    s4 = 0
    cnt = 0
    b = 0
    nflip = 0
    Mprev = M
    for step in range(total):
        cur += 1
        i0 = int(np.random.random()*N)
        s0 = spins[i0]
        stamp[i0] = cur
        clust[0] = i0
        n = 1
        head = 0
        while head < n:
            site = clust[head]
            head += 1
            for k in range(4):
                nb = nbr[site, k]
                if stamp[nb] != cur and spins[nb] == s0:
                    if np.random.random() < padd:
                        stamp[nb] = cur
                        clust[n] = nb
                        n += 1
        for k in range(n):
            spins[clust[k]] = -s0
        M -= 2*s0*n
        if step >= n_therm:
            if (M > 0 and Mprev < 0) or (M < 0 and Mprev > 0):
                nflip += 1
            Mprev = M
            m2 = M*M
            s2 += m2
            s4 += m2*m2
            cnt += 1
            if cnt == block_len:
                S2[b] = s2
                S4[b] = s4
                b += 1
                s2 = 0
                s4 = 0
                cnt = 0
    return S2, S4, nflip

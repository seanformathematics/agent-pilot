
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

class SW:
    """Vectorized Swendsen-Wang over R independent replicas of an N x N periodic Ising lattice (J=1)."""
    def __init__(self, N, R, T, seed):
        self.N = N; self.R = R; self.T = T
        self.n = R * N * N
        self.rng = np.random.default_rng(seed)
        k = np.arange(self.n, dtype=np.int64)
        r = k // (N * N); rem = k % (N * N); i = rem // N; j = rem % N
        self.k = k
        self.nb_right = r * (N * N) + i * N + (j + 1) % N
        self.nb_down = r * (N * N) + ((i + 1) % N) * N + j
        self.p = 1.0 - np.exp(-2.0 / T)   # bond activation prob. for parallel spins
        self.s = self.rng.random(self.n) < 0.5  # bool, True = +1

    def sweep(self):
        s = self.s; n = self.n
        er = (s == s[self.nb_right]) & (self.rng.random(n) < self.p)
        ed = (s == s[self.nb_down]) & (self.rng.random(n) < self.p)
        u = np.concatenate([self.k[er], self.k[ed]])
        v = np.concatenate([self.nb_right[er], self.nb_down[ed]])
        g = csr_matrix((np.ones(u.size, dtype=np.int8), (u, v)), shape=(n, n))
        ncomp, lab = connected_components(g, directed=False)
        flip = self.rng.random(ncomp) < 0.5
        self.s = s ^ flip[lab]

    def mag_sum(self):
        """Per-replica sum of spins M, int64 array of length R."""
        cnt = self.s.reshape(self.R, -1).sum(axis=1).astype(np.int64)
        return 2 * cnt - self.N * self.N

    def energy(self):
        """Per-replica energy E = -(sum over nearest-neighbour pairs of s_i s_j), float array."""
        sp = np.where(self.s, 1.0, -1.0)
        e = -(sp * sp[self.nb_right]).reshape(self.R, -1).sum(axis=1) - (sp * sp[self.nb_down]).reshape(self.R, -1).sum(axis=1)
        return e

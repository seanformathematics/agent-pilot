
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

def make_tables(N):
    idx = np.arange(N*N).reshape(N, N)
    right = np.roll(idx, -1, axis=1).ravel()   # (i,j) -> (i,j+1)
    down = np.roll(idx, -1, axis=0).ravel()    # (i,j) -> (i+1,j)
    return right, down

class SW:
    """Vectorised Swendsen-Wang for R independent N x N Ising replicas (J=1, periodic)."""
    def __init__(self, N, R, T, rng, init="random"):
        self.N = N; self.NN = N*N; self.R = R; self.T = T; self.rng = rng
        self.right, self.down = make_tables(N)
        self.pb = 1.0 - np.exp(-2.0/T)
        if init == "random":
            self.S = rng.choice(np.array([-1, 1], dtype=np.int8), size=(R, self.NN))
        else:
            self.S = np.ones((R, self.NN), dtype=np.int8)
    def sweep(self):
        R, NN = self.R, self.NN
        S = self.S
        ar = (S == S[:, self.right]) & (self.rng.random((R, NN)) < self.pb)
        ad = (S == S[:, self.down]) & (self.rng.random((R, NN)) < self.pb)
        rr, aa = np.nonzero(ar)
        rd, dd = np.nonzero(ad)
        src = np.concatenate([rr*NN + aa, rd*NN + dd])
        dst = np.concatenate([rr*NN + self.right[aa], rd*NN + self.down[dd]])
        n = R*NN
        G = coo_matrix((np.ones(src.size, dtype=np.int8), (src, dst)), shape=(n, n))
        ncomp, lab = connected_components(G, directed=False)
        flip = self.rng.random(ncomp) < 0.5
        f = flip[lab].reshape(R, NN)
        self.S = np.where(f, -S, S).astype(np.int8)
    def m(self):
        return self.S.sum(axis=1, dtype=np.int64) / self.NN

def exact_U(N, T):
    """Exact enumeration (only feasible for small N): returns <m^2>, <m^4>, U."""
    NN = N*N
    states = np.arange(2**NN, dtype=np.int64)
    bits = ((states[:, None] >> np.arange(NN)) & 1).astype(np.int8)*2 - 1
    idx = np.arange(NN).reshape(N, N)
    right = np.roll(idx, -1, axis=1).ravel(); down = np.roll(idx, -1, axis=0).ravel()
    E = -(bits * bits[:, right]).sum(axis=1) - (bits * bits[:, down]).sum(axis=1)
    E = E.astype(float)
    w = np.exp(-(E - E.min())/T)
    m = bits.sum(axis=1)/NN
    Z = w.sum()
    m2 = (w*m**2).sum()/Z; m4 = (w*m**4).sum()/Z
    return m2, m4, 1 - m4/(3*m2**2)

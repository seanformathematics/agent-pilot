
import numpy as np

def U_from_chains(M2, M4):
    """M2, M4: arrays (R, n) of per-sweep m^2 and m^4 values (already burn-in removed).
    Returns full-sample U and jackknife error over replica groups."""
    R = M2.shape[0]
    B2 = M2.mean(); B4 = M4.mean()
    U = 1 - B4/(3*B2**2)
    G = min(100, R)
    edges = np.linspace(0, R, G+1).astype(int)
    s2 = np.array([M2[:a].sum()+M2[b:].sum() for a, b in zip(edges[:-1], edges[1:])])
    s4 = np.array([M4[:a].sum()+M4[b:].sum() for a, b in zip(edges[:-1], edges[1:])])
    n_all = M2.size
    n_g = np.array([M2.size - M2[a:b].size for a, b in zip(edges[:-1], edges[1:])], dtype=float)
    Ug = 1 - (s4/n_g)/(3*(s2/n_g)**2)
    Uj = G*U - (G-1)*Ug.mean()
    err = np.sqrt((G-1)/G*np.sum((Ug - Ug.mean())**2))
    return U, err, Uj

def tau_int(X, maxlag=50):
    """Integrated autocorrelation time (in sweeps) of series X (R, n), replica-averaged ACF."""
    X = X - X.mean()
    R, n = X.shape
    f = np.fft.rfft(X, n=2*n, axis=1)
    acf = np.fft.irfft(f*np.conj(f), n=2*n, axis=1)[:, :n]
    acf = acf.sum(axis=0)
    acf = acf / acf[0]
    tau = 0.5
    for t in range(1, maxlag):
        tau += acf[t]
    return tau

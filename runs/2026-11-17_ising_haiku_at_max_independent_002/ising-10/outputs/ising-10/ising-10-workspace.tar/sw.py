
import numpy as np

def sw_run(T, R, n_steps, n_burn, seed, N=16, S0=None):
    """Swendsen-Wang for R independent replicas of an NxN periodic Ising lattice.
    Returns M (n_steps, R) int16 total magnetization sums (sum of spins), and final spins."""
    rng = np.random.default_rng(seed)
    p = 1.0 - np.exp(-2.0 / T)
    NN = N * N
    if S0 is None:
        S = (rng.integers(0, 2, size=(R, N, N), dtype=np.int8) * np.int8(2) - np.int8(1)).astype(np.int8)
    else:
        S = S0.astype(np.int8).copy()
    base = np.arange(NN, dtype=np.int16).reshape(1, N, N)
    BIG = np.int16(NN + 100)
    M = np.empty((n_steps, R), dtype=np.int16)
    total = n_burn + n_steps
    for step in range(total):
        eqh = S == np.roll(S, -1, axis=2)
        eqv = S == np.roll(S, -1, axis=1)
        bh = eqh & (rng.random((R, N, N)) < p)
        bv = eqv & (rng.random((R, N, N)) < p)
        mR = bh
        mL = np.roll(bh, 1, axis=2)
        mD = bv
        mU = np.roll(bv, 1, axis=1)
        lab = np.broadcast_to(base, (R, N, N)).copy()
        while True:
            nR = np.where(mR, np.roll(lab, -1, axis=2), BIG)
            nL = np.where(mL, np.roll(lab, 1, axis=2), BIG)
            nD = np.where(mD, np.roll(lab, -1, axis=1), BIG)
            nU = np.where(mU, np.roll(lab, 1, axis=1), BIG)
            new = np.minimum(lab, np.minimum(np.minimum(nR, nL), np.minimum(nD, nU)))
            flat = new.reshape(R, NN)
            new = np.take_along_axis(flat, flat.astype(np.intp), axis=1).reshape(R, N, N)
            if np.array_equal(new, lab):
                break
            lab = new
        flags = rng.random((R, NN)) < 0.5
        flip = np.take_along_axis(flags, lab.reshape(R, NN).astype(np.intp), axis=1).reshape(R, N, N)
        S = np.where(flip, -S, S).astype(np.int8)
        if step >= n_burn:
            M[step - n_burn] = S.sum(axis=(1, 2), dtype=np.int32)
    return M, S

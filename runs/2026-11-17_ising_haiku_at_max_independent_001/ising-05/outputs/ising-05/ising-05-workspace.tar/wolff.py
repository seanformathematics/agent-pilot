
import math, random

def make_neighbors(N):
    nbr = []
    for x in range(N):
        for y in range(N):
            nbr.append((((x + 1) % N) * N + y,
                        ((x - 1) % N) * N + y,
                        x * N + (y + 1) % N,
                        x * N + (y - 1) % N))
    return nbr

def wolff_chain(N, T, seed, n_burn, n_blocks, block, cold=False):
    """Wolff cluster algorithm for 2D Ising (J=1, beta=1/T), periodic lattice.
    Returns S2, S4 (lists, one entry per block of `block` measured cluster updates):
      S2[b] = sum of M^2, S4[b] = sum of M^4, M = total spin sum after each update.
    Also returns final M and the number of cluster-flip spins total (diagnostic)."""
    V = N * N
    nbr = make_neighbors(N)
    rnd = random.Random(seed).random
    padd = 1.0 - math.exp(-2.0 / T)
    if cold:
        sp = [1] * V
    else:
        sp = [1 if rnd() < 0.5 else -1 for _ in range(V)]
    M = sum(sp)
    for _ in range(n_burn):
        i0 = int(rnd() * V)
        s0 = sp[i0]
        sp[i0] = -s0
        stack = [i0]
        size = 1
        while stack:
            i = stack.pop()
            for j in nbr[i]:
                if sp[j] == s0 and rnd() < padd:
                    sp[j] = -s0
                    stack.append(j)
                    size += 1
        M -= 2 * s0 * size
    S2 = [0] * n_blocks
    S4 = [0] * n_blocks
    tot_size = 0
    for b in range(n_blocks):
        s2 = 0
        s4 = 0
        for _ in range(block):
            i0 = int(rnd() * V)
            s0 = sp[i0]
            sp[i0] = -s0
            stack = [i0]
            size = 1
            while stack:
                i = stack.pop()
                for j in nbr[i]:
                    if sp[j] == s0 and rnd() < padd:
                        sp[j] = -s0
                        stack.append(j)
                        size += 1
            M -= 2 * s0 * size
            tot_size += size
            M2 = M * M
            s2 += M2
            s4 += M2 * M2
        S2[b] = s2
        S4[b] = s4
    return S2, S4, M, tot_size / (n_blocks * block)

def U_from_sums(sum2, sum4, n):
    # U = 1 - <M^4>/(3 <M^2>^2), with <.> = sum/n ; scale-free in M
    return 1.0 - (sum4 / n) / (3.0 * (sum2 / n) ** 2)

def jackknife_U(S2, S4, G, block):
    """Delete-one-group jackknife over G groups of consecutive blocks.
    block = number of measurements per block. Returns (U_full, err, U_jk_mean)."""
    nb = len(S2)
    gsz = nb // G
    S2g = [sum(S2[k * gsz:(k + 1) * gsz]) for k in range(G)]
    S4g = [sum(S4[k * gsz:(k + 1) * gsz]) for k in range(G)]
    tot2 = sum(S2g); tot4 = sum(S4g)
    ng = gsz * block  # measurements per group
    U_full = U_from_sums(tot2, tot4, G * ng)
    Uk = []
    for k in range(G):
        Uk.append(U_from_sums(tot2 - S2g[k], tot4 - S4g[k], (G - 1) * ng))
    mean = sum(Uk) / G
    var = (G - 1) / G * sum((u - mean) ** 2 for u in Uk)
    return U_full, math.sqrt(var), mean


import numpy as np
import scipy.sparse as sp
from scipy.sparse.csgraph import connected_components


def neighbors(N):
    idx = np.arange(N * N)
    x = idx % N
    y = idx // N
    right = ((x + 1) % N) + N * y
    up = x + N * ((y + 1) % N)
    return right, up


class SW:
    """Swendsen-Wang updates for R independent replicas of an N x N periodic Ising lattice (J=1)."""

    def __init__(self, N, R, seed):
        self.N = N
        self.NN = N * N
        self.R = R
        self.rng = np.random.default_rng(seed)
        self.right, self.up = neighbors(N)
        self.S = (2 * self.rng.integers(0, 2, size=(R, self.NN)) - 1).astype(np.int8)
        self.V = R * self.NN

    def sweep(self, beta):
        p = -np.expm1(-2.0 * beta)  # 1 - exp(-2 beta)
        S = self.S
        eqR = S == S[:, self.right]
        eqU = S == S[:, self.up]
        aR = eqR & (self.rng.random(S.shape) < p)
        aU = eqU & (self.rng.random(S.shape) < p)
        rr, ii = np.nonzero(aR)
        ru, iu = np.nonzero(aU)
        base_r = rr * self.NN
        base_u = ru * self.NN
        src = np.concatenate([base_r + ii, base_u + iu])
        dst = np.concatenate([base_r + self.right[ii], base_u + self.up[iu]])
        G = sp.csr_matrix((np.ones(src.size, dtype=np.int8), (src, dst)), shape=(self.V, self.V))
        ncomp, labels = connected_components(G, directed=False)
        flip = self.rng.random(ncomp) < 0.5
        f = flip[labels].reshape(self.R, self.NN)
        self.S = np.where(f, -S, S).astype(np.int8)

    def mag(self):
        return self.S.sum(axis=1, dtype=np.int64)

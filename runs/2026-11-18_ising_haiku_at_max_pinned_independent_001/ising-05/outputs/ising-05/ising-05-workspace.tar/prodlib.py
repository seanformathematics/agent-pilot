
import numpy as np
import sys
sys.path.insert(0, '/work')
from sw import SW


def run_T(T, R, nburn, nmeas, seed, N=16, block=100):
    sim = SW(N, R, seed)
    beta = 1.0 / T
    for _ in range(nburn):
        sim.sweep(beta)
    S2 = np.zeros(R, dtype=np.int64)
    S4 = np.zeros(R, dtype=np.int64)
    S1 = np.zeros(R, dtype=np.int64)
    nb = nmeas // block
    bS2 = np.zeros(nb)
    bS4 = np.zeros(nb)
    flips = 0
    Mprev = sim.mag()
    for t in range(nmeas):
        sim.sweep(beta)
        M = sim.mag()
        M2 = M * M
        M4 = M2 * M2
        S2 += M2
        S4 += M4
        S1 += M
        flips += int(np.count_nonzero((M > 0) != (Mprev > 0)))
        Mprev = M
        b = t // block
        if b < nb:
            bS2[b] += float(M2.sum())
            bS4[b] += float(M4.sum())
    return dict(S2=S2, S4=S4, S1=S1, bS2=bS2, bS4=bS4, flips=flips,
                R=R, nburn=nburn, nmeas=nmeas, seed=seed, T=T, N=N, block=block)


def U_jack(S2r, S4r, nr):
    R = len(S2r)
    S2 = float(S2r.sum())
    S4 = float(S4r.sum())
    n = float(nr) * R
    U = 1 - (S4 / n) / (3 * (S2 / n) ** 2)
    S2m = S2 - S2r.astype(float)
    S4m = S4 - S4r.astype(float)
    nm = n - nr
    Um = 1 - (S4m / nm) / (3 * (S2m / nm) ** 2)
    err = np.sqrt((R - 1) / R * np.sum((Um - Um.mean()) ** 2))
    return U, err

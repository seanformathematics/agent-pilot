
import random, math, array
import numpy as np

def make_nbrs(L):
    nb = []
    for x in range(L):
        for y in range(L):
            nb.append(((((x+1)%L)*L + y), (((x-1)%L)*L + y), (x*L + (y+1)%L), (x*L + (y-1)%L)))
    return nb

def wolff_run(L, T, nsteps, seed, nburn=0, init_spin=None, spin=None):
    """Run nsteps Wolff cluster updates at temperature T on an LxL periodic Ising lattice.
    Returns (M_array_int32 of length nsteps, final spin list). M = sum of spins (not normalized)."""
    N = L*L
    NB = make_nbrs(L)
    rng = random.Random(seed)
    rnd = rng.random
    padd = 1.0 - math.exp(-2.0/T)
    if spin is None:
        if init_spin is None:
            spin = [1 if rnd() < 0.5 else -1 for _ in range(N)]
        else:
            spin = list(init_spin)
    M = sum(spin)
    # burn-in
    for _ in range(nburn):
        k = int(rnd()*N)
        s0 = spin[k]
        spin[k] = -s0
        stack = [k]
        pop = stack.pop; push = stack.append
        csize = 1
        while stack:
            i = pop()
            for j in NB[i]:
                if spin[j] == s0 and rnd() < padd:
                    spin[j] = -s0
                    push(j)
                    csize += 1
        M -= 2*s0*csize
    Ms = array.array('i', [0])*nsteps
    for t in range(nsteps):
        k = int(rnd()*N)
        s0 = spin[k]
        spin[k] = -s0
        stack = [k]
        pop = stack.pop; push = stack.append
        csize = 1
        while stack:
            i = pop()
            for j in NB[i]:
                if spin[j] == s0 and rnd() < padd:
                    spin[j] = -s0
                    push(j)
                    csize += 1
        M -= 2*s0*csize
        Ms[t] = M
    return np.frombuffer(Ms, dtype=np.int32).copy(), spin

def binder_from_M(M, N2):
    m = M.astype(np.float64)/N2
    m2 = m*m
    m4 = m2*m2
    return 1.0 - m4.mean()/(3.0*m2.mean()**2)

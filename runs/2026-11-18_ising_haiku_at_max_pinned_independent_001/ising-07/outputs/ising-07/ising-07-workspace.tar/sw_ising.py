
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

def make_geometry(L):
    N = L*L
    idx = np.arange(N).reshape(L, L)
    right = np.roll(idx, -1, axis=1).ravel()
    down = np.roll(idx, -1, axis=0).ravel()
    src = np.concatenate([np.arange(N), np.arange(N)])
    dst = np.concatenate([right, down])
    return N, src, dst

class SW:
    def __init__(self, L, R, T, seed, init="random"):
        self.N, self.src, self.dst = make_geometry(L)
        self.R = R; self.T = float(T)
        self.p = 1.0 - np.exp(-2.0/self.T)
        self.rng = np.random.Generator(np.random.PCG64(seed))
        if init == "random":
            self.S = self.rng.choice(np.array([-1, 1], dtype=np.int8), size=(R, self.N))
        else:
            self.S = np.ones((R, self.N), dtype=np.int8)
    def sweep(self):
        R, N = self.S.shape
        S = self.S
        same = S[:, self.src] == S[:, self.dst]
        occ = same & (self.rng.random(same.shape) < self.p)
        r_idx, b_idx = np.nonzero(occ)
        g_src = r_idx*N + self.src[b_idx]
        g_dst = r_idx*N + self.dst[b_idx]
        n = R*N
        g = csr_matrix((np.ones(g_src.size, dtype=np.int8), (g_src, g_dst)), shape=(n, n))
        ncomp, labels = connected_components(g, directed=False)
        flip = self.rng.random(ncomp) < 0.5
        f = flip[labels].reshape(R, N)
        self.S = np.where(f, -S, S).astype(np.int8)

def run_chain(L, R, T, nsweeps, seed, init="random"):
    N, src, dst = make_geometry(L)
    sw = SW(L, R, T, seed, init)
    Ms = np.empty((nsweeps, R), dtype=np.int16)
    Es = np.empty((nsweeps, R), dtype=np.int16)
    for t in range(nsweeps):
        sw.sweep()
        S = sw.S
        Ms[t] = S.sum(axis=1, dtype=np.int64)
        Es[t] = -(S[:, src].astype(np.int64) * S[:, dst]).sum(axis=1)
    return Ms, Es

def jack_U(s2, s4, n_per_bin):
    K = s2.size
    S2 = s2.sum(); S4 = s4.sum(); n = n_per_bin*K
    U_full = 1 - n*S4/(3*S2**2)
    S2k = S2 - s2; S4k = S4 - s4; nk = n - n_per_bin
    Uk = 1 - nk*S4k/(3*S2k**2)
    var = (K-1)/K*np.sum((Uk - Uk.mean())**2)
    return U_full, np.sqrt(var)

def U_from_series(Ms, burn=0):
    x = Ms[burn:].astype(np.float64)
    m2 = np.mean(x**2); m4 = np.mean(x**4)
    return 1 - m4/(3*m2**2)

def U_jack(Ms, B, burn):
    x = Ms[burn:].astype(np.float64)
    nt, R = x.shape
    nb = nt // B
    x = x[:nb*B].reshape(nb, B, R)
    s2 = (x**2).sum(axis=1).ravel()
    s4 = (x**4).sum(axis=1).ravel()
    return jack_U(s2, s4, B)

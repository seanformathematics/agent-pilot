
import sys, time
sys.path.insert(0, "/work")
import numpy as np
from sw import run_sw, binder_pooled, binder_jackknife

# exact enumeration for L=4
def exact_U(L, T):
    NS = L*L
    states = np.arange(2**NS, dtype=np.int64)
    bits = ((states[:, None] >> np.arange(NS)) & 1).astype(np.int64)
    s = (2*bits - 1).reshape(-1, L, L)
    E = np.zeros(len(states))
    for axis in (1, 2):
        E -= (s * np.roll(s, -1, axis=axis)).sum(axis=(1, 2))
    M = s.sum(axis=(1, 2)).astype(float)
    logw = -(E - E.min()) / T
    w = np.exp(logw); w /= w.sum()
    m2 = (w * M**2).sum(); m4 = (w * M**4).sum()
    return 1 - m4 / (3 * m2 * m2), m2 / NS**2

for T in [1.5, 2.0, 2.27, 3.0]:
    Ue, m2e = exact_U(4, T)
    t0 = time.time()
    M2s, M4s, nit = run_sw(4, T, R=512, n_therm=100, n_meas=2000, seed=12345)
    U, err, Ujk = binder_jackknife(M2s, M4s, 2000)
    print(f"L=4 T={T}: exact U={Ue:.5f}  SW U={U:.5f} +- {err:.5f}  (jk {Ujk:.5f})  z={(U-Ue)/err:.2f}  time={time.time()-t0:.1f}s  avg iters/step={nit/(2100):.1f}")

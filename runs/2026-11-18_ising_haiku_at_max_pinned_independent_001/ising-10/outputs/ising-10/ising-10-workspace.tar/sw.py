
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

class SWEngine:
    def __init__(self, L, R, T, seed):
        self.L = L; self.N = L*L; self.R = R; self.T = float(T)
        self.rng = np.random.default_rng(seed)
        idx = np.arange(self.N).reshape(L, L)
        right = np.roll(idx, -1, axis=1)   # bond (x,y)-(x,y+1)
        down = np.roll(idx, -1, axis=0)    # bond (x,y)-(x+1,y)
        self.bi = np.concatenate([idx.ravel(), idx.ravel()]).astype(np.int64)
        self.bj = np.concatenate([right.ravel(), down.ravel()]).astype(np.int64)
        self.p = 1.0 - np.exp(-2.0/self.T)   # SW bond prob for aligned pairs, J=1
        self.spins = (2*self.rng.integers(0, 2, size=(R, self.N)) - 1).astype(np.int8)
        self.V = R*self.N

    def sweep(self):
        s = self.spins
        aligned = s[:, self.bi] == s[:, self.bj]
        u = self.rng.random(aligned.shape)
        active = aligned & (u < self.p)
        rr, bb = np.nonzero(active)
        rows = rr*self.N + self.bi[bb]
        cols = rr*self.N + self.bj[bb]
        g = csr_matrix((np.ones(rows.shape[0], dtype=np.int8), (rows, cols)), shape=(self.V, self.V))
        ncomp, labels = connected_components(g, directed=False)
        flip = self.rng.random(ncomp) < 0.5
        f = flip[labels].reshape(self.R, self.N)
        self.spins = np.where(f, -s, s).astype(np.int8)

def binder_from_sums(B2, B4, n):
    R = len(B2)
    S2 = B2.sum(); S4 = B4.sum()
    m2 = S2/(R*n); m4 = S4/(R*n)
    U = 1 - m4/(3*m2*m2)
    c = (R-1)*n
    m2j = (S2 - B2)/c; m4j = (S4 - B4)/c
    Uj = 1 - m4j/(3*m2j*m2j)
    err = np.sqrt((R-1)/R*np.sum((Uj - Uj.mean())**2))
    return U, err

def run(L, R, T, seed, burn, nsweep):
    eng = SWEngine(L, R, T, seed)
    for _ in range(burn):
        eng.sweep()
    B2 = np.zeros(R); B4 = np.zeros(R)
    for _ in range(nsweep):
        eng.sweep()
        m = eng.spins.sum(axis=1)/eng.N
        m2 = m*m
        B2 += m2; B4 += m2*m2
    return B2, B4

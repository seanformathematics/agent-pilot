
import numpy as np, sys, time
N=16
i,j=np.indices((N,N))
MASKS=[((i+j)%2==0),((i+j)%2==1)]
def run(T,R,nsweep,nburn,seed,block=10,start='cold'):
    rng=np.random.default_rng(seed)
    if start=='cold': s=np.ones((R,N,N),dtype=np.int8)
    else: s=np.where(rng.random((R,N,N))<0.5,1,-1).astype(np.int8)
    thr=np.zeros(9); thr[4]=np.exp(-4/T); thr[8]=np.exp(-8/T)
    nb_blocks=nsweep//block
    M2=np.zeros((nb_blocks,R)); M4=np.zeros((nb_blocks,R))
    tot=nburn+nsweep
    bi=0; acc2=np.zeros(R); acc4=np.zeros(R); c=0
    for sw in range(tot):
        for p in (0,1):
            nb=np.roll(s,1,1)+np.roll(s,-1,1)+np.roll(s,1,2)+np.roll(s,-1,2)
            dE=2*s*nb
            u=rng.random((R,N,N),dtype=np.float32)
            acc=((dE<=0)|(u<thr[np.clip(dE,0,8)])) & MASKS[p]
            s=np.where(acc,-s,s).astype(np.int8)
        if sw>=nburn:
            m=s.reshape(R,-1).mean(axis=1,dtype=np.float64)
            acc2+=m*m; acc4+=m**4; c+=1
            if c==block:
                M2[bi]=acc2/block; M4[bi]=acc4/block; bi+=1
                acc2[:]=0; acc4[:]=0; c=0
    return M2,M4


import numpy as np

def U_from_sums(S2, S4, n):
    M2 = S2 / n
    M4 = S4 / n
    return 1.0 - M4 / (3.0 * M2 ** 2)

def jackknife_U(m2, m4, G):
    """m2, m4: arrays (T, R) of per-sample estimates (R independent replicas, T times).
    Replicas are split into G contiguous groups (independent chains) -> delete-one-group jackknife.
    returns (U_pooled, U_jack_biascorrected, err_jack, n_samples)"""
    T, R = m2.shape
    assert R % G == 0
    k = R // G
    s2 = m2.reshape(T, G, k).sum(axis=(0, 2))
    s4 = m4.reshape(T, G, k).sum(axis=(0, 2))
    ng = T * k
    n = ng * G
    U_all = U_from_sums(s2.sum(), s4.sum(), n)
    Uloo = U_from_sums(s2.sum() - s2, s4.sum() - s4, n - ng)
    Um = Uloo.mean()
    var = (G - 1) / G * np.sum((Uloo - Um) ** 2)
    Ujack = G * U_all - (G - 1) * Um
    return U_all, Ujack, np.sqrt(var), n

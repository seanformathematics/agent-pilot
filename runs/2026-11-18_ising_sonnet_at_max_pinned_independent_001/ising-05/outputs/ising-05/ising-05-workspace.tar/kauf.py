
import numpy as np
def logZ_kaufman(K, N):
    l = np.arange(2 * N)
    cosh_g = np.cosh(2 * K) ** 2 / np.sinh(2 * K) - np.cos(np.pi * l / N)
    g = np.arccosh(cosh_g)
    g[0] = 2 * K + np.log(np.tanh(K))
    godd = g[1::2]; geven = g[0::2]
    def lc(x):
        return np.sum(np.log(2 * np.cosh(N * x / 2)))
    def ls(x):
        v = 2 * np.sinh(N * x / 2)
        return np.sum(np.log(np.abs(v))), np.prod(np.sign(v))
    z1 = lc(godd); z2, s2 = ls(godd); z3 = lc(geven); z4, s4 = ls(geven)
    terms = np.array([z1, z2, z3, z4]); signs = np.array([1.0, s2, 1.0, s4])
    m = terms.max()
    tot = np.sum(signs * np.exp(terms - m))
    return N * N / 2 * np.log(2 * np.sinh(2 * K)) + np.log(0.5) + m + np.log(tot)

def e_exact(T, N, h=1e-5):
    K = 1.0 / T
    return -(logZ_kaufman(K + h, N) - logZ_kaufman(K - h, N)) / (2 * h) / (N * N)

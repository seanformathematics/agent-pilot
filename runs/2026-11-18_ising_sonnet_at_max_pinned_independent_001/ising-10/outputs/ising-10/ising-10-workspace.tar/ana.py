
import numpy as np

def U_from_moments(m2, m4):
    return 1.0 - m4 / (3.0 * m2 ** 2)

def jackknife_U(S2, S4, n):
    """S2, S4: per-replica sums over n measurements of m^2 and m^4 (independent replicas).
    Returns U (ratio of pooled means), delete-one-replica jackknife error, bias-corrected U."""
    S2 = np.asarray(S2, float); S4 = np.asarray(S4, float)
    R = len(S2)
    T2, T4 = S2.sum(), S4.sum()
    U_full = U_from_moments(T2 / (R * n), T4 / (R * n))
    m2_i = (T2 - S2) / ((R - 1) * n)
    m4_i = (T4 - S4) / ((R - 1) * n)
    U_i = U_from_moments(m2_i, m4_i)
    Ubar = U_i.mean()
    err = np.sqrt((R - 1) / R * np.sum((U_i - Ubar) ** 2))
    U_bc = R * U_full - (R - 1) * Ubar
    return U_full, err, U_bc

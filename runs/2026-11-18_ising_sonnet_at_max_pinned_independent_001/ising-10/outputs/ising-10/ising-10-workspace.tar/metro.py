
import numpy as np
class MetroReplicas:
    def __init__(self, N, R, T, rng):
        assert N % 2 == 0
        self.N, self.R, self.T, self.rng = N, R, T, rng
        self.s = (2 * rng.integers(0, 2, size=(R, N, N), dtype=np.int8) - 1).astype(np.int8)
        ii, jj = np.indices((N, N))
        self.mask = [((ii + jj) % 2 == 0)[None], ((ii + jj) % 2 == 1)[None]]
        self.table = np.minimum(1.0, np.exp(-np.arange(-8, 9) / T))   # acceptance prob for dE = -8..8
    def sweep(self):
        s, rng = self.s, self.rng
        for par in (0, 1):
            nn = np.roll(s, 1, axis=1) + np.roll(s, -1, axis=1) + np.roll(s, 1, axis=2) + np.roll(s, -1, axis=2)
            dE = 2 * s * nn
            acc = (rng.random(s.shape) < self.table[dE + 8]) & self.mask[par]
            s[acc] *= -1


import numpy as np

class MetroBatch:
    """R independent N x N periodic Ising lattices, checkerboard Metropolis (J=1,k_B=1)."""
    def __init__(self, N, R, T, seed, start):
        self.N, self.R, self.T = N, R, float(T)
        self.rng = np.random.default_rng(seed)
        s = self.rng.integers(0, 2, size=(R, N, N), dtype=np.int8) * 2 - 1
        flags = np.asarray(start, dtype=bool)
        s[flags] = 1
        self.s = s
        ii, jj = np.indices((N, N))
        par = ((ii + jj) & 1).astype(bool)
        self.par = [~par, par]
        # s*nn in {-4,-2,0,2,4}; dE = 2*s*nn ; acceptance min(1, exp(-dE/T))
        self.acc = np.minimum(1.0, np.exp(-2.0 * np.array([-4, -2, 0, 2, 4]) / self.T)).astype(np.float32)

    def sweep(self):
        s, rng, R, N = self.s, self.rng, self.R, self.N
        for par in self.par:
            nn = np.roll(s, 1, 1) + np.roll(s, -1, 1) + np.roll(s, 1, 2) + np.roll(s, -1, 2)
            k = (s * nn + 4) >> 1
            a = self.acc[k]
            r = rng.random((R, N, N), dtype=np.float32)
            flip = (r < a) & par
            s *= (1 - 2 * flip.astype(np.int8))
        return s.reshape(R, -1).sum(axis=1, dtype=np.int32)

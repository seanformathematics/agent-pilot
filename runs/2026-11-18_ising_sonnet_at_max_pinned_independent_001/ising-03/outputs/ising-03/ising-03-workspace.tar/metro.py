
import numpy as np

def metropolis_run(N, R, T, seed, n_equil, n_meas, start="hot", B=100, e_every=0):
    """Checkerboard single-spin-flip Metropolis, R independent replicas.
    Returns per-replica block means (block B sweeps) of m^2, m^4 and energy/site (energy every sweep of last
    sweep in block only -> cheap)."""
    rng = np.random.default_rng(seed)
    if start == "hot":
        s = (2 * rng.integers(0, 2, (R, N, N), dtype=np.int8) - 1).astype(np.int8)
    else:
        s = np.ones((R, N, N), dtype=np.int8)
    acc = np.array([min(1.0, np.exp(-2.0 * k / T)) for k in range(-4, 5)], dtype=np.float32)
    ii, jj = np.meshgrid(np.arange(N), np.arange(N), indexing="ij")
    mask = [((ii + jj) % 2 == c)[None] for c in (0, 1)]
    def sweep(s):
        for c in (0, 1):
            nn = np.roll(s, 1, 1) + np.roll(s, -1, 1) + np.roll(s, 1, 2) + np.roll(s, -1, 2)
            k = s * nn
            p = acc[k + 4]
            u = rng.random((R, N, N), dtype=np.float32)
            flip = (u < p) & mask[c]
            s = np.where(flip, -s, s)
        return s
    for t in range(n_equil):
        s = sweep(s)
    nb = n_meas // B
    blk = np.zeros((2, R, nb))
    eacc_tot = np.zeros(R); ecount = 0
    for b in range(nb):
        a2 = np.zeros(R); a4 = np.zeros(R)
        for t in range(B):
            s = sweep(s)
            m = s.sum(axis=(1, 2), dtype=np.int32) / float(N * N)
            m2 = m * m
            a2 += m2; a4 += m2 * m2
            if e_every and (t % e_every) == 0:
                s16 = s.astype(np.int16)
                eacc_tot += -(s16 * np.roll(s16, -1, axis=2) + s16 * np.roll(s16, -1, axis=1)).sum(axis=(1, 2)) / float(N * N); ecount += 1
        blk[0, :, b] = a2 / B; blk[1, :, b] = a4 / B
    return dict(blk=blk, N=N, R=R, T=T, seed=seed, n_equil=n_equil, n_meas=nb * B, B=B, start=start, e_rep=(eacc_tot / max(ecount, 1)))

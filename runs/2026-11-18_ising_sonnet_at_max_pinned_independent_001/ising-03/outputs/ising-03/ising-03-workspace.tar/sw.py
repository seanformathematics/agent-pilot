
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components


class IsingSW:
    """Swendsen-Wang for the 2D Ising model (J=1, kB=1), many independent replicas at once.
    Replicas never interact: the batched graph has no edges between replicas."""

    def __init__(self, N, R, T, seed, start="hot"):
        self.N, self.R, self.T = N, R, T
        self.rng = np.random.default_rng(seed)
        self.V = R * N * N
        idx = np.arange(self.V, dtype=np.int32).reshape(R, N, N)
        self.idx = idx
        self.right = np.roll(idx, -1, axis=2)
        self.down = np.roll(idx, -1, axis=1)
        self.p = 1.0 - np.exp(-2.0 / T)
        self.indptr = np.arange(0, 2 * self.V + 1, 2, dtype=np.int32)
        self.data = np.ones(2 * self.V)
        self.rep_of_node = np.repeat(np.arange(R, dtype=np.int32), N * N)
        if start == "hot":
            self.s = (2 * self.rng.integers(0, 2, (R, N, N), dtype=np.int8) - 1).astype(np.int8)
        elif start == "cold":
            self.s = np.ones((R, N, N), dtype=np.int8)
        elif start == "mixed":   # half hot, half cold
            s = (2 * self.rng.integers(0, 2, (R, N, N), dtype=np.int8) - 1).astype(np.int8)
            s[R // 2:] = 1
            self.s = s
        else:
            raise ValueError(start)
        self.ind = np.empty((self.V, 2), dtype=np.int32)

    def sweep(self, improved=False):
        """One SW update of all replicas. If improved: return per-replica improved
        estimators (m2, m4) computed from cluster sizes (conditional expectation over the
        random cluster flips)."""
        N, R, V = self.N, self.R, self.V
        s = self.s
        rng = self.rng
        u = rng.random((2, R, N, N), dtype=np.float32)
        bh = (s == np.roll(s, -1, axis=2)) & (u[0] < self.p)
        bv = (s == np.roll(s, -1, axis=1)) & (u[1] < self.p)
        ind = self.ind
        ind[:, 0] = np.where(bh, self.right, self.idx).ravel()
        ind[:, 1] = np.where(bv, self.down, self.idx).ravel()
        g = csr_matrix((self.data, ind.ravel(), self.indptr), shape=(V, V))
        nc, lab = connected_components(g, directed=False)
        flip = rng.integers(0, 2, nc, dtype=np.int8)
        sign = (1 - 2 * flip)[lab].astype(np.int8)
        self.s = (s.reshape(-1) * sign).reshape(R, N, N)
        if improved:
            sizes = np.bincount(lab, minlength=nc).astype(np.float64)
            rep = np.empty(nc, dtype=np.int32)
            rep[lab] = self.rep_of_node
            S2 = np.bincount(rep, weights=sizes ** 2, minlength=R)
            S4 = np.bincount(rep, weights=sizes ** 4, minlength=R)
            n2 = float(N * N)
            m2 = S2 / n2 ** 2
            m4 = (3.0 * S2 ** 2 - 2.0 * S4) / n2 ** 4
            return m2, m4
        return None

    def magnetization(self):
        return self.s.sum(axis=(1, 2), dtype=np.int32) / float(self.N ** 2)

    def energy_per_site(self):
        s = self.s.astype(np.int16)
        e = -(s * np.roll(s, -1, axis=2) + s * np.roll(s, -1, axis=1)).sum(axis=(1, 2))
        return e / float(self.N ** 2)


class IsingMetropolis:
    """Checkerboard Metropolis, many independent replicas (used only as an independent cross-check)."""

    def __init__(self, N, R, T, seed, start="hot"):
        assert N % 2 == 0
        self.N, self.R, self.T = N, R, T
        self.rng = np.random.default_rng(seed)
        if start == "hot":
            self.s = (2 * self.rng.integers(0, 2, (R, N, N), dtype=np.int8) - 1).astype(np.int8)
        else:
            self.s = np.ones((R, N, N), dtype=np.int8)
        ii, jj = np.meshgrid(np.arange(N), np.arange(N), indexing="ij")
        self.mask = [((ii + jj) % 2 == c) for c in (0, 1)]
        # acceptance prob for dE = 2*s*nn, nn in {-4,-2,0,2,4}: s*nn in {-4,..,4}
        self.acc = {k: min(1.0, np.exp(-2.0 * k / T)) for k in (-4, -2, 0, 2, 4)}

    def sweep(self):
        s = self.s
        R, N = self.R, self.N
        for c in (0, 1):
            nn = (np.roll(s, 1, 1).astype(np.int8) + np.roll(s, -1, 1) + np.roll(s, 1, 2) + np.roll(s, -1, 2))
            k = s * nn
            pacc = np.where(k <= 0, 1.0, np.exp(-2.0 * k.astype(np.float64) / self.T))
            u = self.rng.random((R, N, N))
            flip = (u < pacc) & self.mask[c][None]
            s = np.where(flip, -s, s).astype(np.int8)
        self.s = s

    def magnetization(self):
        return self.s.sum(axis=(1, 2), dtype=np.int32) / float(self.N ** 2)


def run_T(N, R, T, seed, n_equil, n_meas, B=100, start="mixed", e_every=1, n_series=4):
    """Run R independent replicas at temperature T with Swendsen-Wang.
    Returns dict with per-replica block averages (blocks of B sweeps) of plain and improved m^2, m^4,
    burn-in trajectories (ensemble mean of m^2 for the hot-start half and cold-start half),
    energies and a short raw time series for autocorrelation analysis."""
    S = IsingSW(N, R, T, seed, start)
    half = R // 2
    traj_hot = np.zeros(n_equil); traj_cold = np.zeros(n_equil)
    for t in range(n_equil):
        S.sweep()
        m2 = S.magnetization() ** 2
        traj_hot[t] = m2[:half].mean(); traj_cold[t] = m2[half:].mean()
    nb = n_meas // B
    blk = np.zeros((4, R, nb))
    eblk = np.zeros((R, nb)); ecount = 0
    series = np.zeros((n_series, n_meas))   # raw m^2 series, replicas 0..n_series-1
    for b in range(nb):
        acc = np.zeros((4, R)); eacc = np.zeros(R); ne = 0
        for t in range(B):
            a, bb = S.sweep(improved=True)
            m = S.magnetization()
            m2 = m * m
            acc[0] += m2; acc[1] += m2 * m2; acc[2] += a; acc[3] += bb
            series[:, b * B + t] = m2[:n_series]
            if (t % e_every) == 0:
                eacc += S.energy_per_site(); ne += 1
        blk[:, :, b] = acc / B
        eblk[:, b] = eacc / max(ne, 1)
    return dict(blk=blk, eblk=eblk, traj_hot=traj_hot, traj_cold=traj_cold, series=series, N=N, R=R, T=T, seed=seed,
                n_equil=n_equil, n_meas=nb * B, B=B)


def U_jack(S2, S4):
    """Jackknife (delete-one replica) estimate of U = 1 - <m4>/(3<m2>^2) from per-replica means S2, S4
    (every replica contributes the same number of samples). Returns U, err."""
    R = len(S2)
    A = S2.sum(); Bs = S4.sum()
    U0 = 1.0 - (Bs / R) / (3.0 * (A / R) ** 2)
    a = (A - S2) / (R - 1); b = (Bs - S4) / (R - 1)
    Ul = 1.0 - b / (3.0 * a ** 2)
    err = np.sqrt((R - 1) / R * ((Ul - Ul.mean()) ** 2).sum())
    return U0, err


import numpy as np

def _log2cosh(x):
    ax = np.abs(x)
    return ax + np.log1p(np.exp(-2*ax))
def _log2sinh_abs(x):
    ax = np.abs(x)
    return ax + np.log1p(-np.exp(-2*ax))

def lnZ_torus(K, m, n, gamma0_sign=+1):
    """ln Z for an m x n torus, isotropic coupling K = 1/T (J=1), Z = sum exp(K sum s s')."""
    Ks = -0.5*np.log(np.tanh(K))
    l = np.arange(2*n)
    cg = np.cosh(2*K)*np.cosh(2*Ks) - np.sinh(2*K)*np.sinh(2*Ks)*np.cos(np.pi*l/n)
    gam = np.arccosh(np.maximum(cg, 1.0))
    gam[0] = gamma0_sign*(2*K - 2*Ks)
    odd = gam[1::2]; even = gam[0::2]
    L = []; S = []
    L.append(_log2cosh(m*odd/2).sum()); S.append(1.0)
    L.append(_log2sinh_abs(m*odd/2).sum()); S.append(1.0)
    L.append(_log2cosh(m*even/2).sum()); S.append(1.0)
    L.append(_log2sinh_abs(m*even/2).sum()); S.append(np.sign(np.prod(np.sign(even))))
    L = np.array(L); S = np.array(S)
    Lmax = L.max()
    tot = np.sum(S*np.exp(L-Lmax))
    return np.log(0.5) + 0.5*m*n*np.log(2*np.sinh(2*K)) + Lmax + np.log(tot)

def energy_per_spin_exact(T, N, h=1e-5):
    K = 1.0/T
    d = (lnZ_torus(K+h, N, N) - lnZ_torus(K-h, N, N))/(2*h)
    return -d/(N*N)


import numpy as np
import sw

def run_T(N, T, R, n_eq, n_meas, B, seed, start="hot", eq_trace=False):
    """Run R independent replicas: n_eq SW equilibration updates, then n_meas measured updates.
    Returns block means (B updates per block) of [m2, m4, i2, i4, e] with shape (5, R, nblocks)."""
    b = sw.SWBatch(N, R, T, seed, start)
    tr = []
    for t in range(n_eq):
        b.step()
        if eq_trace:
            m, e = b.observables()
            tr.append((e.mean(), (m**2).mean()))
    nb = n_meas // B
    out = np.zeros((5, R, nb))
    n2 = float(N**2); n4 = float(N**4); n8 = float(N**8)
    for ib in range(nb):
        acc = np.zeros((5, R))
        for k in range(B):
            S2, S4 = b.step()
            m, e = b.observables()
            m2 = m * m
            acc[0] += m2
            acc[1] += m2 * m2
            acc[2] += S2 / n4
            acc[3] += (3.0 * S2 * S2 - 2.0 * S4) / n8
            acc[4] += e
        out[:, :, ib] = acc / B
    return out, np.array(tr)

def U_from(m2, m4):
    return 1.0 - m4 / (3.0 * m2 * m2)

def jack_U(X, i2, i4):
    """X: (5,R,nb) block means. Jackknife over replicas for U built from rows (i2,i4). Returns U, err."""
    A = X[i2].mean(axis=1)   # per-replica mean of m2   (equal block counts -> equal weights)
    Bq = X[i4].mean(axis=1)
    R = A.shape[0]
    sA, sB = A.sum(), Bq.sum()
    U = U_from(sA / R, sB / R)
    Uj = U_from((sA - A) / (R - 1), (sB - Bq) / (R - 1))
    err = np.sqrt((R - 1) / R * np.sum((Uj - Uj.mean())**2))
    return U, err

def jack_mean(x):
    R = x.shape[0]
    return x.mean(), x.std(ddof=1) / np.sqrt(R)

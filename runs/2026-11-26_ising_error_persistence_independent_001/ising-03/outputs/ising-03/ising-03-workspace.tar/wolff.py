
import random, math, time, json, sys
N=16
T=float(sys.argv[1]); seed=int(sys.argv[2]); nclus=int(sys.argv[3]); out=sys.argv[4]
BIN=2000; EQ=20000
rng = random.Random(seed)
L=N*N
nb=[]
for i in range(L):
    x,y=i%N,i//N
    nb.append((((x+1)%N)+y*N, ((x-1)%N)+y*N, x+((y+1)%N)*N, x+((y-1)%N)*N))
s=[rng.choice((-1,1)) for _ in range(L)]
M=sum(s)
p=1-math.exp(-2.0/T)
rnd=rng.random
for _ in range(EQ):
    i=int(rnd()*L); sg=s[i]; s[i]=-sg; stack=[i]
    while stack:
        j=stack.pop()
        for k in nb[j]:
            if s[k]==sg and rnd()<p:
                s[k]=-sg; stack.append(k)
    # recompute M lazily below
M=sum(s)
bins=[]
s2=s4=0.0; cnt=0
t0=time.time()
for c in range(nclus):
    i=int(rnd()*L); sg=s[i]; s[i]=-sg; stack=[i]; size=1
    while stack:
        j=stack.pop()
        for k in nb[j]:
            if s[k]==sg and rnd()<p:
                s[k]=-sg; stack.append(k); size+=1
    M-=2*sg*size
    m2=M*M
    s2+=m2; s4+=m2*m2; cnt+=1
    if cnt==BIN:
        bins.append((s2/BIN/L/L, s4/BIN/L**2/L**2 if False else s4/BIN/(L*L)**2))
        s2=s4=0.0; cnt=0
res=dict(T=T,seed=seed,nclus=nclus,bins=bins,time=time.time()-t0)
json.dump(res,open(out,'w'))
print('done',T,seed,len(bins),time.time()-t0)

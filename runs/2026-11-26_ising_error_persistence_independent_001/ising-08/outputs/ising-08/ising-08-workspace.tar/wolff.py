
import math, random, sys, time, numpy as np
N=16; L=N*N
nb=[]
for i in range(L):
    r,c=divmod(i,N)
    nb.append((((r+1)%N)*N+c,((r-1)%N)*N+c,r*N+(c+1)%N,r*N+(c-1)%N))
def run(T, seed, time_budget, nburn=2000, maxrec=None):
    rng=random.Random(seed)
    s=[rng.choice((-1,1)) for _ in range(L)]
    M=sum(s)
    p=1-math.exp(-2.0/T)
    rnd=rng.random; rr=rng.randrange
    rec=[]
    t0=time.time()
    k=0
    while True:
        i=rr(L); sg=s[i]; s[i]=-sg; stack=[i]; size=1
        while stack:
            q=stack.pop()
            for j in nb[q]:
                if s[j]==sg and rnd()<p:
                    s[j]=-sg; stack.append(j); size+=1
        M-=2*sg*size
        k+=1
        if k>nburn: rec.append(M)
        if (k & 1023)==0 and time.time()-t0>time_budget: break
    return np.array(rec,dtype=np.int32), k

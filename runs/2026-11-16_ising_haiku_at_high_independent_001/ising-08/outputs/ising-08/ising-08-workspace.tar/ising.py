
import numpy as np, sys, time
N=16
def run(T, seed, R=400, nequil=2000, nmeas=20000):
    rng=np.random.default_rng(seed)
    S=rng.choice(np.array([-1,1],dtype=np.int8),size=(R,N,N))
    ii,jj=np.meshgrid(np.arange(N),np.arange(N),indexing='ij')
    masks=[((ii+jj)%2==0),((ii+jj)%2==1)]
    def sweep(S):
        for par in (0,1):
            nn=(np.roll(S,1,1)+np.roll(S,-1,1)+np.roll(S,1,2)+np.roll(S,-1,2)).astype(np.int8)
            dE=2*S*nn
            acc=(dE<=0)|(rng.random(S.shape)<np.exp(-np.clip(dE,0,None)/T))
            S[acc & masks[par]] *= -1
    for _ in range(nequil): sweep(S)
    m2s=np.zeros(R); m4s=np.zeros(R); ms=np.zeros(R)
    series=np.zeros((nmeas,R),dtype=np.float32)
    for t in range(nmeas):
        sweep(S)
        m=S.reshape(R,-1).mean(axis=1)
        m2s+=m*m; m4s+=m**4; ms+=np.abs(m)
        series[t]=m
    return m2s/nmeas, m4s/nmeas, ms/nmeas, series

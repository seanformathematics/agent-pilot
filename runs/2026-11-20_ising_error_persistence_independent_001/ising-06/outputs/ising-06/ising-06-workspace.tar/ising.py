
import random, math, sys, time
def run(N, T, nsweeps_meas, seed, therm_clusters, out_path=None):
    rng = random.Random(seed)
    L = N*N
    nb = [[0]*4 for _ in range(L)]
    for x in range(N):
        for y in range(N):
            i = x*N+y
            nb[i][0] = ((x+1)%N)*N+y
            nb[i][1] = ((x-1)%N)*N+y
            nb[i][2] = x*N+(y+1)%N
            nb[i][3] = x*N+(y-1)%N
    s = [1]*L
    padd = 1.0-math.exp(-2.0/T)
    rand = rng.random; randint = rng.randrange
    M = L  # total spin sum
    def cluster_flip(M):
        i0 = randint(L)
        s0 = s[i0]
        s[i0] = -s0
        stack = [i0]
        size = 1
        while stack:
            i = stack.pop()
            for j in nb[i]:
                if s[j] == s0 and rand() < padd:
                    s[j] = -s0
                    stack.append(j)
                    size += 1
        return size*(-2*s0)  # change in sum
    S = sum(s)
    for _ in range(therm_clusters):
        S += cluster_flip(S)
    res = []
    for _ in range(nsweeps_meas):
        S += cluster_flip(S)
        m = S/L
        res.append(m)
    return res

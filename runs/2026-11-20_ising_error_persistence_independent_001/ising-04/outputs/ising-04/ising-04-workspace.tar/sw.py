
import numpy as np, time, sys
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
N=16
idx=np.arange(N*N).reshape(N,N)
EA=np.concatenate([idx.ravel(), idx.ravel()])
EB=np.concatenate([np.roll(idx,-1,axis=1).ravel(), np.roll(idx,-1,axis=0).ravel()])
def run(T, nsweep, nequil, seed, out):
    rng=np.random.default_rng(seed)
    p=1-np.exp(-2.0/T)
    s=np.where(rng.random(N*N)<0.5,1,-1).astype(np.int64)
    m2=np.empty(nsweep); m4=np.empty(nsweep)
    tot=nequil+nsweep
    for it in range(tot):
        same=(s[EA]==s[EB])
        keep=same & (rng.random(EA.size)<p)
        a=EA[keep]; b=EB[keep]
        g=coo_matrix((np.ones(a.size,dtype=np.int8),(a,b)),shape=(N*N,N*N))
        nc,lab=connected_components(g,directed=False)
        flip=rng.random(nc)<0.5
        s=np.where(flip[lab],-s,s)
        if it>=nequil:
            m=s.sum()/(N*N)
            m2[it-nequil]=m*m; m4[it-nequil]=m**4
    np.savez(out, m2=m2, m4=m4, T=T, seed=seed, nequil=nequil)
if __name__=="__main__":
    T=float(sys.argv[1]); ns=int(sys.argv[2]); ne=int(sys.argv[3]); seed=int(sys.argv[4]); out=sys.argv[5]
    t=time.time(); run(T,ns,ne,seed,out); print("done",time.time()-t)


import numpy as np

def make_masks(N):
    ii, jj = np.meshgrid(np.arange(N), np.arange(N), indexing='ij')
    black = ((ii + jj) % 2 == 0)
    return black, ~black

def run_chains(N, T, R, n_equil, n_meas, seed, init='random', thin=1):
    """Run R independent Metropolis chains in parallel; return per-sweep m, m2, m4, e arrays (n_meas/thin, R)."""
    rng = np.random.default_rng(seed)
    beta = 1.0 / T
    black, white = make_masks(N)
    if init == 'random':
        s = rng.choice(np.array([-1, 1], dtype=np.int8), size=(R, N, N))
    elif init == 'cold':
        s = np.ones((R, N, N), dtype=np.int8)
    else:
        raise ValueError
    # acceptance table indexed by x = s*nn in {-4,-2,0,2,4}; dE = 2*x; accept prob min(1, exp(-2 beta x))
    xs = np.arange(-4, 5, 2)
    ptab = np.minimum(1.0, np.exp(-2.0 * beta * xs)).astype(np.float64)
    # index = x + 4 in {0,2,4,6,8}
    ptab_full = np.zeros(9)
    ptab_full[xs + 4] = ptab
    mask_b = black[None]
    mask_w = white[None]
    def half(s, cmask):
        nn = (np.roll(s, 1, axis=1) + np.roll(s, -1, axis=1) +
              np.roll(s, 1, axis=2) + np.roll(s, -1, axis=2))
        x = s * nn  # int8
        p = ptab_full[(x + 4).astype(np.intp)]
        u = rng.random(s.shape)
        flip = (u < p) & cmask
        return np.where(flip, -s, s).astype(np.int8)
    def sweep(s):
        s = half(s, mask_b)
        s = half(s, mask_w)
        return s
    for _ in range(n_equil):
        s = sweep(s)
    nkeep = n_meas // thin
    M = np.zeros((nkeep, R)); M2 = np.zeros((nkeep, R)); M4 = np.zeros((nkeep, R)); E = np.zeros((nkeep, R))
    k = 0
    Nsq = N * N
    for t in range(n_meas):
        s = sweep(s)
        if (t + 1) % thin == 0:
            sf = s.reshape(R, Nsq).astype(np.float64)
            m = sf.mean(axis=1)
            M[k] = m; M2[k] = m * m; M4[k] = m ** 4
            bonds = (s * np.roll(s, -1, axis=1)).astype(np.int32).sum(axis=(1, 2)) + \
                    (s * np.roll(s, -1, axis=2)).astype(np.int32).sum(axis=(1, 2))
            E[k] = -bonds / Nsq
            k += 1
    return M, M2, M4, E, s

def binder_jack(M2, M4):
    """M2, M4: (n_samples, R) arrays. Returns U, U_err via jackknife over chains."""
    R = M2.shape[1]
    a2 = M2.mean(axis=0); a4 = M4.mean(axis=0)  # per chain
    A2 = a2.sum(); A4 = a4.sum()
    U_full = 1 - (A4 / R) / (3 * (A2 / R) ** 2)
    # leave-one-out
    A2_i = A2 - a2; A4_i = A4 - a4
    U_i = 1 - (A4_i / (R - 1)) / (3 * (A2_i / (R - 1)) ** 2)
    U_jack = U_i.mean()
    err = np.sqrt((R - 1) / R * np.sum((U_i - U_i.mean()) ** 2))
    return U_full, err

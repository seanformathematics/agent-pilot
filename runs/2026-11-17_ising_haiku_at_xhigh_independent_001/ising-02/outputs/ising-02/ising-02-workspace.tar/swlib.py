
import numpy as np, scipy.sparse as sp, scipy.sparse.csgraph as csg, time
N=16; NN=N*N
Ts=np.array([1.5,1.6,1.7,1.8,1.9,2.0,2.1,2.2,2.3,2.4,2.5,2.6,2.7,2.8])

def setup(T_rep):
    R=len(T_rep)
    p=1-np.exp(-2.0/np.asarray(T_rep,float))
    idx=np.arange(NN).reshape(N,N)
    right=np.roll(idx,-1,axis=1); down=np.roll(idx,-1,axis=0)
    bu=np.concatenate([idx.ravel(),idx.ravel()])
    bv=np.concatenate([right.ravel(),down.ravel()])
    off=(np.arange(R)*NN)[:,None]
    U=(bu[None,:]+off).ravel(); V=(bv[None,:]+off).ravel()
    rep=np.repeat(np.arange(R),2*NN)
    return p,U,V,rep

def sw_sweep(s,rng,p,U,V,rep,R):
    aligned=s[U]==s[V]
    keep=aligned&(rng.random(U.size)<p[rep])
    uu=U[keep]; vv=V[keep]
    g=sp.csr_matrix((np.ones(uu.size,dtype=np.int8),(uu,vv)),shape=(R*NN,R*NN))
    ncomp,labels=csg.connected_components(g,directed=False)
    flip=(rng.integers(0,2,size=ncomp)*2-1).astype(np.int8)
    return s*flip[labels]

def jk_U(S2,S4,groups_idx):
    """S2,S4: per-replica sums of m^2, m^4 (same count n each). Returns U, err per group."""
    out=[]
    for gi in groups_idx:
        a2=S2[gi]; a4=S4[gi]; g=len(gi)
        def U_of(x2,x4):
            m2=x2.mean(); m4=x4.mean()
            return 1-m4/(3*m2*m2)
        Ufull=U_of(a2,a4)
        tot2=a2.sum(); tot4=a4.sum()
        loo=np.empty(g)
        for k in range(g):
            m2=(tot2-a2[k])/(g-1); m4=(tot4-a4[k])/(g-1)
            loo[k]=1-m4/(3*m2*m2)
        err=np.sqrt((g-1)/g*np.sum((loo-loo.mean())**2))
        out.append((Ufull,err))
    return out

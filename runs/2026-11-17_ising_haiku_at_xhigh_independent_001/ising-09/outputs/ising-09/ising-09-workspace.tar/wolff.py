
import numpy as np, sys
assert sys.byteorder == "little"

class PackedWolff:
    def __init__(self, N, W, T, seed, K=24):
        self.N = N; self.W = W; self.T = T
        self.rng = np.random.default_rng(seed)
        p = 1.0 - np.exp(-2.0 / T)
        self.p = p
        self.K = K
        self.P = int(round(p * 2**K))
        self.S = self.rng.integers(0, 2**64, size=(W, N, N), dtype=np.uint64)
        self.bitvals = [np.uint64(1) << np.uint64(b) for b in range(64)]
        self.shape = (W, N, N)

    def bern(self):
        X = np.zeros(self.shape, dtype=np.uint64)
        for k in range(self.K, 0, -1):
            R = self.rng.integers(0, 2**64, size=self.shape, dtype=np.uint64)
            if (self.P >> (self.K - k)) & 1:
                X |= R
            else:
                X &= R
        return X

    def step(self):
        N, W = self.N, self.W
        S = self.S
        Bx = ~(S ^ np.roll(S, -1, axis=1)) & self.bern()
        By = ~(S ^ np.roll(S, -1, axis=2)) & self.bern()
        C = np.zeros(self.shape, dtype=np.uint64)
        Cf = C.reshape(W, N * N)
        idx = self.rng.integers(0, N * N, size=(W, 64))
        ar = np.arange(W)
        for b in range(64):
            Cf[ar, idx[:, b]] |= self.bitvals[b]
        F = C.copy()
        while True:
            new = np.roll(F & Bx, 1, axis=1)
            new |= np.roll(F, -1, axis=1) & Bx
            new |= np.roll(F & By, 1, axis=2)
            new |= np.roll(F, -1, axis=2) & By
            new &= ~C
            if not new.any():
                break
            C |= new
            F = new
        self.S = S ^ C
        return C

    def counts(self):
        N, W = self.N, self.W
        b = self.S.view(np.uint8).reshape(W, N, N, 8)
        bits = np.unpackbits(b, axis=-1, bitorder='little')
        return bits.sum(axis=(1, 2), dtype=np.int32).reshape(W * 64)

def run(N, W, T, seed, nburn, nmeas, block=100):
    sim = PackedWolff(N, W, T, seed)
    for _ in range(nburn):
        sim.step()
    L = W * 64
    s2 = np.zeros(L); s4 = np.zeros(L)
    nb = nmeas // block
    blk2 = np.zeros((nb, L)); blk4 = np.zeros((nb, L))
    cnt = 0
    NN = N * N
    for t in range(nb):
        b2 = np.zeros(L); b4 = np.zeros(L)
        for j in range(block):
            sim.step()
            n = sim.counts()
            m = (2.0 * n - NN) / NN
            m2 = m * m
            b2 += m2; b4 += m2 * m2
        s2 += b2; s4 += b4
        blk2[t] = b2 / block; blk4[t] = b4 / block
        cnt += block
    return dict(s2=s2, s4=s4, cnt=cnt, blk2=blk2, blk4=blk4)

def binder_from_sums(s2, s4, cnt):
    m2 = s2.sum() / (len(s2) * cnt)
    m4 = s4.sum() / (len(s4) * cnt)
    return 1.0 - m4 / (3.0 * m2 * m2)

def jackknife_U(s2, s4, cnt):
    L = len(s2)
    T2 = s2.sum(); T4 = s4.sum()
    m2c = (T2 - s2) / ((L - 1) * cnt)
    m4c = (T4 - s4) / ((L - 1) * cnt)
    Uc = 1.0 - m4c / (3.0 * m2c * m2c)
    U = 1.0 - (T4 / (L * cnt)) / (3.0 * (T2 / (L * cnt)) ** 2)
    var = (L - 1) / L * np.sum((Uc - Uc.mean()) ** 2)
    return U, np.sqrt(var)
